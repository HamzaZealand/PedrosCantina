-- Testdata til Pedros Cantina.
-- Kør dette script efter CreateTables.sql.
-- Scriptet opretter medarbejdere, vagter for hele 2026 og tildelinger.
-- Færdige vagter har 2-3 personer og mindst én leder.

USE PedrosCantina;
GO

DELETE FROM dbo.ShiftAssignment;
DELETE FROM dbo.Shift;
DELETE FROM dbo.Employee;
GO

DBCC CHECKIDENT ('dbo.Shift', RESEED, 0);
GO

SET IDENTITY_INSERT dbo.Employee ON;

INSERT INTO dbo.Employee (EmployeeId, Name, Phone, Email, IsManager)
VALUES
    (1, N'Pedro Gonzalez',  N'20112233', N'pedro@pedroscantina.dk',  1),
    (2, N'Jacoby Nielsen',  N'20223344', N'jacoby@pedroscantina.dk', 1),
    (3, N'Maria Hansen',    N'30334455', N'maria@pedroscantina.dk',  0),
    (4, N'Anders Larsen',   N'40445566', N'anders@pedroscantina.dk', 0),
    (5, N'Sofia Berg',      N'50556677', N'sofia@pedroscantina.dk',  0),
    (6, N'Emil Kristensen', N'60667788', N'emil@pedroscantina.dk',   0);

SET IDENTITY_INSERT dbo.Employee OFF;
DBCC CHECKIDENT ('dbo.Employee', RESEED, 6);
GO

-- To vagter hver dag i 2026: 09:00-14:00 og 14:00-19:00.
DECLARE @shiftDate DATE = '2026-01-01';

WHILE @shiftDate <= '2026-12-31'
BEGIN
    INSERT INTO dbo.Shift (ShiftDate, StartTime, EndTime)
    VALUES (@shiftDate, '09:00', '14:00');

    INSERT INTO dbo.Shift (ShiftDate, StartTime, EndTime)
    VALUES (@shiftDate, '14:00', '19:00');

    SET @shiftDate = DATEADD(DAY, 1, @shiftDate);
END
GO

-- Rotation: én leder + én almindelig medarbejder på hverdage,
-- og én leder + to almindelige medarbejdere i weekenden.
SET DATEFIRST 1; -- Mandag = 1, søndag = 7

DECLARE @shiftId INT;
DECLARE @shiftDate DATE;
DECLARE @startTime TIME;
DECLARE @dayNum INT;
DECLARE @isWeekend BIT;
DECLARE @morningManager INT;
DECLARE @afternoonManager INT;
DECLARE @regular1 INT;
DECLARE @regular2 INT;
DECLARE @regular3 INT;

DECLARE shiftCursor CURSOR FOR
    SELECT ShiftId, ShiftDate, StartTime
    FROM dbo.Shift
    ORDER BY ShiftDate, StartTime;

OPEN shiftCursor;
FETCH NEXT FROM shiftCursor INTO @shiftId, @shiftDate, @startTime;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dayNum = DATEDIFF(DAY, '2026-01-01', @shiftDate);
    SET @isWeekend = CASE WHEN DATEPART(WEEKDAY, @shiftDate) IN (6, 7) THEN 1 ELSE 0 END;

    -- EmployeeId 1 = Pedro, 2 = Jacoby, 3-6 = almindelige medarbejdere
    SET @morningManager = CASE WHEN @dayNum % 2 = 0 THEN 1 ELSE 2 END;
    SET @afternoonManager = CASE WHEN @dayNum % 2 = 0 THEN 2 ELSE 1 END;
    SET @regular1 = 3 + (@dayNum % 4);
    SET @regular2 = 3 + ((@dayNum + 1) % 4);
    SET @regular3 = 3 + ((@dayNum + 2) % 4);

    IF @startTime = '09:00:00'
    BEGIN
        INSERT INTO dbo.ShiftAssignment (ShiftId, EmployeeId)
        VALUES (@shiftId, @morningManager);

        INSERT INTO dbo.ShiftAssignment (ShiftId, EmployeeId)
        VALUES (@shiftId, @regular1);

        IF @isWeekend = 1
        BEGIN
            INSERT INTO dbo.ShiftAssignment (ShiftId, EmployeeId)
            VALUES (@shiftId, @regular3);
        END
    END
    ELSE
    BEGIN
        INSERT INTO dbo.ShiftAssignment (ShiftId, EmployeeId)
        VALUES (@shiftId, @afternoonManager);

        INSERT INTO dbo.ShiftAssignment (ShiftId, EmployeeId)
        VALUES (@shiftId, @regular2);

        IF @isWeekend = 1
        BEGIN
            INSERT INTO dbo.ShiftAssignment (ShiftId, EmployeeId)
            VALUES (@shiftId, @regular3);
        END
    END

    FETCH NEXT FROM shiftCursor INTO @shiftId, @shiftDate, @startTime;
END

CLOSE shiftCursor;
DEALLOCATE shiftCursor;
GO
